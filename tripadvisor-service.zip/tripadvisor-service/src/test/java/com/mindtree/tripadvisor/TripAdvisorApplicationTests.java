package com.mindtree.tripadvisor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripAdvisorApplicationTests {

	@Test
	void contextLoads() {
	}

}
