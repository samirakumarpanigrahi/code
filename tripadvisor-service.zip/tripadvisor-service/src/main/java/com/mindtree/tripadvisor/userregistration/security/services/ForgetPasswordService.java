package com.mindtree.tripadvisor.userregistration.security.services;

import org.springframework.mail.MailException;

import com.mindtree.tripadvisor.userregistration.entity.User;
import com.mindtree.tripadvisor.userregistration.exception.UserRegistractionException;

public interface ForgetPasswordService {

	int sendEmail(String email) throws MailException, UserRegistractionException;


	String updatePassword(User user) throws UserRegistractionException;

	

}
