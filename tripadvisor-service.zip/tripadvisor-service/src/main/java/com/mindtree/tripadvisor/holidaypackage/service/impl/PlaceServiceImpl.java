package com.mindtree.tripadvisor.holidaypackage.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.mindtree.tripadvisor.holidaypackage.dto.HolidayPackageDto;
import com.mindtree.tripadvisor.holidaypackage.dto.PlaceDto;
import com.mindtree.tripadvisor.holidaypackage.entity.HolidayPackage;
import com.mindtree.tripadvisor.holidaypackage.entity.Place;
import com.mindtree.tripadvisor.holidaypackage.repository.PlaceRepository;
import com.mindtree.tripadvisor.holidaypackage.service.PlaceService;

@Service
public class PlaceServiceImpl implements PlaceService {


	@Autowired
	PlaceRepository placeRepository;
	private ModelMapper model= new ModelMapper();
	@Override
	public PlaceDto getPackagesByPlace(String name) {
		Place place=placeRepository.findByDestinationIgnoreCase(name);
//		List<HolidayPackage> packagess=place.getPackages();
//		List<HolidayPackageDto> dtoPackages = new ArrayList<>();
//		HolidayPackageDto pdto=null;
//		for(HolidayPackage p:packagess)
//		{
//			pdto=model.map(p, HolidayPackageDto.class);
//			 dtoPackages.add(pdto);
//		}
		PlaceDto placeDto= new PlaceDto();
		System.out.println("1");
		placeDto=model.map(place, PlaceDto.class);
		return placeDto;
	}
	
	

}
