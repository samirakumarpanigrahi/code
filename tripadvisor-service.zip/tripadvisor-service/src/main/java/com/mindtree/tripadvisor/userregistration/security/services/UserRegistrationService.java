package com.mindtree.tripadvisor.userregistration.security.services;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.mindtree.tripadvisor.userregistration.exception.UserRegistractionException;
import com.mindtree.tripadvisor.userregistration.message.request.SignUpForm;

public interface UserRegistrationService {

	/**
	 * @param signUpRequest
	 * @return
	 * @throws UserRegistractionException
	 */
	String addUser(@Valid SignUpForm signUpRequest) throws UserRegistractionException;



}
