/**
 * 
 */
package com.mindtree.tripadvisor.searchhotel.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.tripadvisor.searchhotel.entity.Hotel;
import com.mindtree.tripadvisor.searchhotel.repository.HotelRepository;
import com.mindtree.tripadvisor.searchhotel.service.HotelService;

/**
 * @author M1056135
 *
 */

@Service
public class HotelServiceImpl implements HotelService {
	@Autowired
	HotelRepository hotelRepository;

	@Override
	public List<Hotel> getHotelBasedOnPlace(String place) {
		return hotelRepository.findAllByCity(place);
	}

}
