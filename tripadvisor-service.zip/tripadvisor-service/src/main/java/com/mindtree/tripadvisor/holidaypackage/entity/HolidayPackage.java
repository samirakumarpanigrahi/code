package com.mindtree.tripadvisor.holidaypackage.entity;

import java.util.Arrays;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

//@JsonIdentityInfo(generator= ObjectIdGenerators.PropertyGenerator.class, property="packageId")
//@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
@Entity
@Table
public class HolidayPackage {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int packageId;
	private String packageType;
	private String packageName;
	private int days;
	private int nights;
	private long budget;

	@ManyToOne(cascade=CascadeType.ALL)
	private Place places;
	
	private String packageImage;


	public int getPackage_id() {
		return packageId;
	}
	public void setPackage_id(int package_id) {
		this.packageId = package_id;
	}
	public String getPackage_type() {
		return packageType;
	}
	public void setPackage_type(String package_type) {
		this.packageType = package_type;
	}
	public String getPackage_name() {
		return packageName;
	}
	public void setPackage_name(String package_name) {
		this.packageName = package_name;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	public int getNights() {
		return nights;
	}
	public void setNights(int nights) {
		this.nights = nights;
	}
	public long getBudget() {
		return budget;
	}
	public void setBudget(long budget) {
		this.budget = budget;
	}
	@JsonIgnore
	public Place getPlaces() {
		return places;
	}
	public void setPlaces(Place places) {
		this.places = places;
	}
	public String getPackage_image() {
		return packageImage;
	}
	public void setPackage_image(String package_image) {
		this.packageImage = package_image;
	}


	
	
	@Override
	public String toString() {
		return "HolidayPackage [packageId=" + packageId + ", packageType=" + packageType + ", packageName="
				+ packageName + ", days=" + days + ", nights=" + nights + ", budget=" + budget + ", places=" + places
				+ ", packageImage=" + packageImage + "]";
	}
	public HolidayPackage(int package_id, String package_type, String package_name, int days, int nights, long budget,
			Place places, String package_image) {
		super();
		this.packageId = package_id;
		this.packageType = package_type;
		this.packageName = package_name;
		this.days = days;
		this.nights = nights;
		this.budget = budget;
		this.places = places;
		this.packageImage = package_image;
		
		
	}
	public HolidayPackage() {
		super();
		
	}


}
