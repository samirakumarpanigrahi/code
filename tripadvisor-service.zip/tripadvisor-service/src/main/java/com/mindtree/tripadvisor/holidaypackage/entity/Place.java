package com.mindtree.tripadvisor.holidaypackage.entity;

import java.util.Arrays;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

//@JsonIdentityInfo(generator= ObjectIdGenerators.PropertyGenerator.class, property="placeId")
//@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
@Entity
@Table
public class Place {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int placeId;
	private String destination;
	private String description;
	@ManyToOne(cascade=CascadeType.ALL)
	private Season seasons;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="places")
	
	private List<HolidayPackage> packages;

	
	private String placeImage;

	public int getPlace_id() {
		return placeId;
	}

	public void setPlace_id(int place_id) {
		this.placeId = place_id;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
     
	public Season getSeasons() {
		return seasons;
	}

	public void setSeasons(Season seasons) {
		this.seasons = seasons;
	}

	public List<HolidayPackage> getPackages() {
		return packages;
	}

	public void setPackages(List<HolidayPackage> packages) {
		this.packages = packages;
	}

	public String getPlace_image() {
		return placeImage;
	}

	public void setPlace_image(String place_image) {
		this.placeImage = place_image;
	}

	

	@Override
	public String toString() {
		return "Place [placeId=" + placeId + ", destination=" + destination + ", description=" + description
				+ ", seasons=" + seasons + ", packages=" + packages + ", placeImage=" + placeImage + "]";
	}

	public Place(int place_id, String destination, String description, Season seasons, List<HolidayPackage> packages,
			String place_image) {
		super();
		this.placeId = place_id;
		this.destination = destination;
		this.description = description;
		this.seasons = seasons;
		this.packages = packages;
		this.placeImage = place_image;
	}

	public Place() {
		super();
	}

}
