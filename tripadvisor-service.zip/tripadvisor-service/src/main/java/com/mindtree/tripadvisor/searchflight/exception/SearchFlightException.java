package com.mindtree.tripadvisor.searchflight.exception;

public class SearchFlightException {

}
