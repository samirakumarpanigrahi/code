package com.mindtree.tripadvisor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class TripAdvisorApplication {

	public static void main(String[] args) {
		SpringApplication.run(TripAdvisorApplication.class, args);
	}
protected SpringApplicationBuilder configure(SpringApplicationBuilder appliccation) {
		return appliccation.sources(TripAdvisorApplication.class);
	} 

}
