package com.mindtree.tripadvisor.userregistration.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
public class ForgetPassword {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

	
    private String email;

    
    private int code;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public ForgetPassword( @NotBlank @Size(min = 3, max = 50) String email, @NotBlank int code) {
		super();
		
		this.email = email;
		this.code = code;
	}

	public ForgetPassword() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
    
    
    
    

}
