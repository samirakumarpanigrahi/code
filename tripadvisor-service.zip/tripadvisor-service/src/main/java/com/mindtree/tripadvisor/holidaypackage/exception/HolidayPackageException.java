package com.mindtree.tripadvisor.holidaypackage.exception;

public class HolidayPackageException {

}
