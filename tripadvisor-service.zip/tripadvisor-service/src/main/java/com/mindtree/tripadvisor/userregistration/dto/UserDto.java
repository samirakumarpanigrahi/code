package com.mindtree.tripadvisor.userregistration.dto;

public class UserDto {

}
