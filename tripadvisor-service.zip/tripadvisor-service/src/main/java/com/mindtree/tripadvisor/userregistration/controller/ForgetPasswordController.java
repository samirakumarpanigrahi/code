package com.mindtree.tripadvisor.userregistration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.tripadvisor.userregistration.entity.ForgetPassword;
import com.mindtree.tripadvisor.userregistration.entity.User;
import com.mindtree.tripadvisor.userregistration.exception.UserRegistractionException;
import com.mindtree.tripadvisor.userregistration.security.services.ForgetPasswordService;


@RestController
@CrossOrigin
@RequestMapping("forgatepassword")
public class ForgetPasswordController {
	
	@Autowired
	ForgetPasswordService mailService;
	
	@PostMapping("sendmail")
	public int sendEmail(@RequestBody String email ) throws MailException, UserRegistractionException
	
	{
		System.out.println(email);
		return mailService.sendEmail(email);
	}
		
	@PostMapping("update")
	public String updatePassword(@RequestBody User user) throws UserRegistractionException

	{
		return mailService.updatePassword(user);
	}
	
	

}
