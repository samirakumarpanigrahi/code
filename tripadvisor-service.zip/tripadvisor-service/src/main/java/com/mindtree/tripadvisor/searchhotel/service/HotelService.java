package com.mindtree.tripadvisor.searchhotel.service;

import java.util.List;

import com.mindtree.tripadvisor.searchhotel.entity.Hotel;

public interface HotelService {

	List<Hotel> getHotelBasedOnPlace(String place);

}
